import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from password_strength import PasswordPolicy

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance2.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/", methods=["GET"])
@login_required
def index():
    """Show portfolio of stocks"""
    if request.method == "GET":
        current_user = session["user_id"]
        rows_symbol = db.execute("SELECT symbol FROM stock WHERE user_id = :owner", owner=current_user)
        rows_name = db.execute("SELECT name FROM stock WHERE user_id = :owner", owner=current_user)
        rows_shares = db.execute("SELECT shares FROM stock WHERE user_id = :owner", owner=current_user)
        rows_price = db.execute("SELECT price FROM stock WHERE user_id = :owner", owner=current_user)
        rows_tprice = db.execute("SELECT tprice FROM stock WHERE user_id = :owner", owner=current_user)
        cash = db.execute("SELECT cash FROM users WHERE id = :owner", owner=current_user)

        balance0 = cash[0]["cash"]

        #balance1 = ["{:,}".format(balance0)]

        #balance = balance1[0]

        user_symbol = []
        user_name = []
        user_shares = []
        user_price1 = []
        user_tprice1 = []
        user_tprice2 = []

        

        for symbols in rows_symbol:
            user_symbol.append(symbols["symbol"])
        for names in rows_name:
            user_name.append(names["name"])
        for shares in rows_shares:
            user_shares.append(shares["shares"])
        #for price in rows_price:
            #user_price1.append(round(price["price"], 2))
        for price in rows_price:
            user_price1.append(usd(price["price"]))
        #for tprice in rows_tprice:
            #user_tprice1.append(round(tprice["tprice"], 2))
        for tprice in rows_tprice:
            user_tprice1.append(usd(tprice["tprice"]))
        for tprice_sum in rows_tprice:
            user_tprice2.append((tprice_sum["tprice"]))
        
        #user_price2 = ["{:,}".format(elem) for elem in user_price1]

        #user_tprice2 = ["{:,}".format(elem) for elem in user_tprice1]

        #user_price = user_price2
        #user_tprice = user_tprice2
            
        counts = len(user_symbol)
        #
        user_total = sum(user_tprice2)

        #total1 = cash[0]["cash"] + user_total

        total1 = cash[0]["cash"] + user_total

        #totals2 = ["{:,}".format(total1)]

        #totals = totals2[0]
        #flash("Welcome!")
        #flash("Sold!")
        #flash("Bought!")
        #flash("Logged out!")
        return render_template("index.html", rows_symbol=user_symbol, rows_name=user_name, rows_shares=user_shares,
            rows_price=user_price1, rows_tprice=user_tprice1, cash=usd(balance0), total=usd(total1), countx=counts)
    #return apology("TODO")


@app.route("/admin_index", methods=["GET"])
@login_required
def gindex():
    if request.method == "GET":
        return render_template("admin_index.html")

@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        #TODO
        current_user = session['user_id']
        form_symbol = request.form.get("symbol")
        form_shares = int(request.form.get("shares"))

        if form_shares == None or form_symbol == "" or form_shares < 1:
            return apology("Sorry you must provide a stock name and/or share(s)", 403)
        else:

            stock = lookup(form_symbol)
            if stock == None:
                return apology("Sorry stock not available", 403)
            else:
                price = stock["price"]
                stock_symbol = stock["symbol"]
                stock_name = stock["name"]
                tprice = round((float(price * form_shares)), 2)

                cash = db.execute("SELECT cash FROM users WHERE id = :owner", owner=current_user)

                user_cash = cash[0]["cash"]
                #owner_cash = float(user_cash)

                if user_cash >= tprice:
                    user_stock = db.execute("SELECT symbol FROM stock WHERE user_id = :owner AND (symbol = :stksymboldb OR symbol = :fsymboldb)",
                                          owner=current_user, stksymboldb=stock_symbol, fsymboldb=form_symbol)
                    #if len(user_stock) != 1:
                        #user_symbol = user_stock[0]["symbol"]
                    
                    if len(user_stock) != 1:
                        db.execute("INSERT INTO stock(user_id, symbol, name, shares, price, tprice) VALUES(:owner, :symboldb, :namedb, :sharesdb, :pricedb, :tpricedb)",
                                  owner=current_user,  symboldb=stock_symbol, namedb=stock_name, sharesdb=form_shares, pricedb=price, tpricedb=tprice)
                        new_balance = round((user_cash - tprice), 2)
                        db.execute("UPDATE users SET cash = :balance WHERE id = :owner", balance=new_balance, owner=current_user)
                    else:
                        owner_price = db.execute("SELECT tprice FROM stock WHERE user_id = :owner AND symbol = (SELECT symbol FROM stock WHERE symbol = :symboldb)",
                                                owner=current_user, symboldb=stock_symbol)
                        owner_shares = db.execute("SELECT shares FROM stock WHERE user_id = :owner AND symbol = :symboldb",
                                                owner=current_user, symboldb=stock_symbol)
                        owner_old_price = owner_price[0]["tprice"]
                        owner_old_shares = owner_shares[0]["shares"]
                        new_shares = owner_old_shares + form_shares
                        new_tprice = round((owner_old_price + tprice), 2)

                        current_cash = db.execute("SELECT cash FROM users WHERE id = :owner", owner=current_user)
                        user_new_cash = current_cash[0]["cash"]
                        new_balance = round((user_new_cash - tprice), 2)

                        #update user's cash and update the total of their stock pice in the stock table 
                        db.execute("UPDATE stock SET shares=:sharesdb, price=:pricedb, tprice=:tpricedb WHERE user_id = :owner AND symbol= :symboldb",
                                  sharesdb=new_shares, pricedb=price, tpricedb=new_tprice, owner=current_user, symboldb=stock_symbol)
                        db.execute("UPDATE users SET cash = :balance WHERE id = :owner", balance=new_balance, owner=current_user)

                    # insert into the buy and history table
                    db.execute("INSERT INTO buy(user_id, symbol, shares, price, tprice) VALUES(:owner, :symboldb, :sharesdb, :pricedb, :tpricedb)",
                              owner=current_user, symboldb=stock_symbol, sharesdb=form_shares, pricedb=price, tpricedb=tprice)
                    db.execute("INSERT INTO history(user_id, symbol, shares, price, tprice) VALUES(:owner, :symboldb, :sharesdb, :pricedb, :tpricedb)",
                              owner=current_user, symboldb=stock_symbol, sharesdb=form_shares, pricedb=price, tpricedb=tprice)
                    db.execute("INSERT INTO ghistory(user_id, activity) VALUES(:owner, :activitydb)", owner=current_user, activitydb="Bought")
                    flash("Bought!")
                    return redirect("/")
                else:
                    return apology("Sorry you can't afford this stock", 403)

        #return apology("TODO")
    else:
        return render_template("buy.html")

    


@app.route("/history", methods=["GET"])
@login_required
def history():
    """Show history of transactions"""
    if request.method == "GET":
        current_user = session["user_id"]
        rows_symbol = db.execute("SELECT symbol FROM history WHERE user_id = :owner", owner=current_user)
        rows_shares = db.execute("SELECT shares FROM history WHERE user_id = :owner", owner=current_user)
        rows_price = db.execute("SELECT price FROM history WHERE user_id = :owner", owner=current_user)
        rows_transacted = db.execute("SELECT transacted FROM history WHERE user_id = :owner", owner=current_user)

        user_symbol = []
        user_shares = []
        user_price1 = []
        user_transacted = []

        for symbols in rows_symbol:
            user_symbol.append(symbols["symbol"])
        for shares in rows_shares:
            user_shares.append(shares["shares"])
        for price in rows_price:
            user_price1.append(usd(price["price"]))
        for time in rows_transacted:
            user_transacted.append(time["transacted"])
            
        #user_price2 = ["{:,}".format(elem) for elem in user_price1]
        #user_price = user_price2

        counts = len(user_symbol)
        return render_template("history.html",
            rows_symbol=user_symbol, rows_shares=user_shares, rows_price=user_price1, rows_transacted=user_transacted, count=counts)

@app.route("/admin_history", methods=["GET"])
@login_required
def ghistory():
    """Show history of transactions"""
    if request.method == "GET":
        current_user = session["admin"]
        rows_symbol = db.execute("SELECT id FROM ghistory")
        rows_shares = db.execute("SELECT user_id FROM ghistory")
        rows_price = db.execute("SELECT activity FROM ghistory")
        rows_transacted = db.execute("SELECT time FROM ghistory")

        user_symbol = []
        user_shares = []
        user_price = []
        user_transacted = []

        for symbols in rows_symbol:
            user_symbol.append(symbols["id"])
        for shares in rows_shares:
            user_shares.append(shares["user_id"])
        for price in rows_price:
            user_price.append(price["activity"])
        for time in rows_transacted:
            user_transacted.append(time["time"])
            
        counts = len(user_symbol)
        return render_template("admin_history.html",
            rows_id=user_symbol, rows_user_id=user_shares,
            rows_activity=user_price, rows_time=user_transacted, count=counts)

    #return apology("TODO")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        flash("Welcome!")
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/admin_login", methods=["GET", "POST"])
def glogin():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM admin WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["admin"] = rows[0]["id"]

        # Redirect user to home page
        flash("Welcome!")
        return redirect("/admin_index")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("admin_login.html")

@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    flash("Logged out!")
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":
        symbol = request.form.get("symbol")
        stock = lookup(symbol)

        if stock == None or stock == "":
            return apology("Sorry stock not available", 403)
        else:
            stock_name = stock['name']
            stock_symbol = stock['symbol']
            stock_price = stock['price']
            #print(stock)
            return render_template("quote2.html", message1=stock_name, message2=stock_symbol, message3=stock_price)
    else:
        return render_template("quote.html")
    #return apology("TODO")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    policy = PasswordPolicy.from_names(length=8, uppercase=2, numbers=2, special=2, nonletters=2)

    if request.method == "GET":
        return render_template("register.html")
    else:
        username = request.form.get("username")
        password1 = request.form.get("password1")
        password2 = request.form.get("password2")

        policy = PasswordPolicy.from_names(length=8, uppercase=2, numbers=2, special=2, nonletters=2)
        strength = policy.test(password1)
        if len(strength) == 0:
            if username =="" or password2 =="":
                return apology("Please you must provide username and/or password", 403)
            else:
                if password1 == password2:
                    usernamedb = db.execute("SELECT username FROM users WHERE username = :usernamedb", usernamedb=username)
                    if len(usernamedb) != 1:
                        pswd_hash = generate_password_hash(password2)
                        db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", username, pswd_hash)
                        
                        user = db.execute("SELECT MAX(id) AS id FROM users")

                        session["user_id"] = user[0]["id"]
                        current_user = session["user_id"]

                        db.execute("INSERT INTO ghistory(user_id, activity) VALUES(:owner, :activitydb)", owner=current_user, activitydb="Registered")

                        cash = db.execute("SELECT cash FROM users WHERE id = :owner", owner=current_user)
                        user_cash = cash[0]["cash"]

                        flash("Registered!")
                        return render_template("index.html", cash=user_cash, total=user_cash, countx=0, strengths=strength)
                    else:
                        return apology("Sorry Username already Taken")
                else:
                    return apology("Password mismatch!!!")
        else:
            return apology("Password not strong!", 403)


@app.route("/admin_register", methods=["GET", "POST"])
def gregister():
    """Register user"""

    policy = PasswordPolicy.from_names(length=8, uppercase=2, numbers=2, special=2, nonletters=2)

    if request.method == "GET":
        return render_template("admin_register.html")
    else:
        username = request.form.get("username")
        password1 = request.form.get("password1")
        password2 = request.form.get("password2")

        policy = PasswordPolicy.from_names(length=8, uppercase=2, numbers=2, special=2, nonletters=2)
        strength = policy.test(password1)
        if len(strength) == 0:
            if username =="" or password2 =="":
                return apology("Please you must provide username and/or password", 403)
            else:
                if password1 == password2:
                    usernamedb = db.execute("SELECT username FROM admin WHERE username = :usernamedb", usernamedb=username)
                    if len(usernamedb) != 1:
                        pswd_hash = generate_password_hash(password2)
                        db.execute("INSERT INTO admin (username, hash) VALUES (?, ?)", username, pswd_hash)
                        
                        user = db.execute("SELECT MAX(id) AS id FROM admin")

                        session["admin"] = user[0]["id"]
                        current_user = session["admin"]

                        db.execute("INSERT INTO ghistory(user_id, activity) VALUES(:owner, :activitydb)", owner=current_user, activitydb="Admin registered")

                        flash("Admin registered!")
                        return render_template("admin_index.html")
                    else:
                        return apology("Sorry Username already Taken")
                else:
                    return apology("Password mismatch!!!")
        else:
            return apology("Password not strong!", 403)

    #return apology("TODO")


@app.route("/password", methods=["GET", "POST"])
@login_required
def password():
    if request.method == "GET":
        return render_template("password.html")
    else:

        old = request.form.get("old")
        new1 = request.form.get("new1")
        new2 = request.form.get("new2")

        current_user = session["user_id"]
        policy = PasswordPolicy.from_names(length=8, uppercase=2, numbers=2, special=2, nonletters=2)
        strength = policy.test(password1)
        if len(strength) == 0:
            if not old or not new1 or not new2:
                return apology("All field must be validated", 403)
            rows = db.execute("SELECT hash FROM users WHERE id = :owner", owner=current_user)

            if not check_password_hash(rows[0]["hash"], old):
                return apology("Old password invalid!", 403)
            else:
                if new1 == new2:
                    db.execute("UPDATE users SET hash = :new_passdb WHERE id = :owner", new_passdb=generate_password_hash(new2), owner=current_user)
                    db.execute("INSERT INTO ghistory(user_id, activity) VALUES(:owner, :activitydb)",
                        owner=current_user, activitydb="Password Changed")
                    flash("Password changed successfully")
                    return redirect("/")
                else:
                    return apology("Confirm Password", 403)
        else:
            return apology("Password not strong", 403)
        #return apology("TODO")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    #Todo
    current_user = session["user_id"]
    rows = db.execute("SELECT symbol FROM stock WHERE user_id= :owner", owner=current_user)

    if request.method == "GET":
        return render_template("sell.html", rows=rows)
    else:
        form_symbol = request.form.get("symbol")
        shares = request.form.get("shares")
        form_shares = shares

        if form_shares != "" or form_symbol != "" or form_symbol != NULL:

            form_shares = int(shares)
            if form_shares >= 1:
                user_shares = db.execute("SELECT shares FROM stock WHERE user_id = :owner AND symbol = :symboldb",
                                        owner=current_user, symboldb=form_symbol)
                user_current_shares = user_shares[0]["shares"]
                if user_current_shares > form_shares:
                    stock = lookup(form_symbol)
                    stock_price = stock["price"]
                    stock_symbol = stock["symbol"]

                    tprice = stock_price * form_shares

                    cash = db.execute("SELECT cash FROM users WHERE id = :owner", owner=current_user)
                    user_cash = cash[0]["cash"]
                    if user_cash > tprice:
                        #user_shares = db.execute("SELECT shares FROM stock WHERE user_id = :owner AND (symbol = :stksymboldb OR symbol = :fsymboldb)",
                                                  #owner=current_user, stksymboldb=stock_symbol, fsymboldb=form_symbol)
                        owner_tprice = db.execute("SELECT DISTINCT tprice FROM stock WHERE user_id = :owner AND (symbol = :stksymboldb OR symbol = :fsymboldb)",
                                                        owner=current_user, stksymboldb=stock_symbol, fsymboldb=form_symbol)
                        
                        user_current_tprice = owner_tprice[0]["tprice"]
                        new_tprice = user_current_tprice - tprice
                        new_shares = user_current_shares - form_shares
                        new_balance = round(user_cash + tprice, 2)
                        form_shares_history = 0 - form_shares

                        db.execute("INSERT INTO history(user_id, symbol, shares, price, tprice) VALUES(:current_userdb, :stock_symboldb, :form_shares_historydb, :stock_pricedb, :stock_tpricedb)",
                                    current_userdb=current_user, stock_symboldb=stock_symbol, form_shares_historydb=form_shares_history,
                                    stock_pricedb=stock_price, stock_tpricedb=tprice)
                        db.execute("INSERT INTO ghistory(user_id, activity) VALUES(:owner, :activitydb)", owner=current_user, activitydb="Sold")
                        db.execute("INSERT INTO sell(user_id, symbol, shares, price, tprice) VALUES(:owner, :symboldb, :sharesdb, :pricedb, :tpricedb)",
                                      owner=current_user, symboldb=stock_symbol, sharesdb=form_shares, pricedb=stock_price, tpricedb=tprice)
                        db.execute("UPDATE stock SET shares = :current_sharesdb, tprice = :tpricedb WHERE user_id = :owner AND (symbol = :stksymboldb OR symbol = :fsymboldb)",
                                    current_sharesdb=new_shares, tpricedb=new_tprice, owner=current_user, stksymboldb=stock_symbol, fsymboldb=form_symbol)
                        db.execute("UPDATE users SET cash = :new_balancedb WHERE id = :owner",
                                    new_balancedb=new_balance, owner=current_user)
                        flash("Sold!")
                        return redirect("/")

                    else:
                        return apology("Sorry you can't afford this stock", 403)
                else:
                    return apology("Sorry you can't sell upto this shares of stock", 403)
            else:
                return apology("Sorry you can't sell upto this shares of stock", 403)
            
        else:
            return apology("Sorry you must provide no of shares", 403)
        #return apology("TODO")

    
    #return apology("TODO")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
